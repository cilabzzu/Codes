% %% genarate ture PS PF
% function genpspf()
% a=1;
% b=10;
% c=8;
% no=400;%�������Ž����
% %PS
% no1=fix(no/9);%����ÿ�����ֽ�ĸ���
% %���������������
% x11=linspace(-(3*a+c),-(a+c),no1);
% x12=linspace(-a,a,no1);
% x13=linspace(a+c,3*a+c,no1);
% 
% tempx1=[x11,x12,x13];
% x21=repmat(b,1,length(tempx1));
% x22=zeros(1,length(tempx1));
% x23=repmat(-b,1,length(tempx1));
% x2=[x21,x22,x23];
% x1=repmat([x11,x12,x13],1,3);
% 
%������ת���true_PS
%% xx1=cos(w)*x1+sin(w)*x2;
%% xx2=-sin(w)*x1+cos(w)*x2;
% PS=[x1x',xx2'];
% for i=1:size(PS,1)
%     PF(i,:)=Testfunction6_SYM_PART(PS(i,:));
% end
% figure(1)
% plot(PS(:,1),PS(:,2),'ro');
% figure(2)
% plot(PF(:,1),PF(:,2),'ro');
% save TF6_2_turePFPS PF PS
% end
function y=Testfunction6_3_SYM_PART(x)
%�ο�����[Rudolph G, Naujoks B, Preuss M. Capabilities of EMOA to detect and preserve equivalent Pareto subsets[C]//Evolutionary Multi-Criterion Optimization. Springer Berlin/Heidelberg, 2007: 36-50.]
a=1;
b=10;
c=8;
w=pi/4;
%% f3������
U=20;
L=-20;
e=0.01;
d=x(1).*(((x(2)-L+e)/(U-L)).^(-1));
x(1)=d;
x(2)=x(2);
%% f2 ������
xx1=cos(w)*x(1)-sin(w)*x(2);
xx2=sin(w)*x(1)+cos(w)*x(2);
x(1)=xx1;
x(2)=xx2;
%%
temp_t1=sign(x(1))*ceil((abs(x(1))-(a+c/2))/(2*a+c));
temp_t2=sign(x(2))*ceil((abs(x(2))-b/2)/b);
t1=sign(temp_t1)*min(abs(temp_t1),1);
t2=sign(temp_t2)*min(abs(temp_t2),1);

x1=x(1)-t1*(c+2*a);
x2=x(2)-t2*b;



y=fun([x1,x2],a);


end


function y=fun(x,a)
y=zeros(2,1);
y(1)=(x(1)+a)^2+x(2)^2;
y(2)=(x(1)-a)^2+x(2)^2;

end



