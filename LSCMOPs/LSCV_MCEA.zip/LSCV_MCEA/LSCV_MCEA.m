classdef LSCV_MCEA < ALGORITHM
    % <multi> <real/binary/permutation> <constrained>
    
    methods
        function main(Algorithm,Problem)
            
            maxGen=ceil(Problem.maxFE/Problem.N);
            [X,gen]= Algorithm.ParameterSet(0,1);
            N1=Problem.N*0.3;
            %% Generate random population
            Population1 = Problem.Initialization();
            Population2 = Problem.Initialization();
            Population2=Population2(1:N1);
            Population3= Population2;

            
           
            VAR0=max(Population1.cons);
            f1=find(Population2.cons==0);
            f2=find(Population3.cons==0);
            
            Fitness1    = CalFitness(Population1.objs,Population1.cons,VAR0);
            Fitness2=Single_Fitness(f1,Population2,gen,VAR0,N1,maxGen,1);
            Fitness3=Single_Fitness(f2,Population3,gen,VAR0,N1,maxGen,2);
            

            %% Optimization
            while Algorithm.NotTerminated(Population1)
                
                cp=(-log(VAR0)-6)/log(1-0.5);
                %             adjust the threshold
                if X < 0.5
                    VAR=VAR0*(1-X)^cp;
                else
                    VAR=0;
                end
                
                MatingPool= TournamentSelection(2,Problem.N,Fitness1);
                Offspring1  = OperatorGAhalf(Population1(MatingPool));
                ind2=TournamentSelection(2,N1,Fitness2);
                ind3=TournamentSelection(2,N1,Fitness3);
                Offspring2  = OperatorGAhalf(Population2(ind2));
                Offspring3  = OperatorGAhalf(Population3(ind3));

                % 种群1
                [Population1,Fitness1] = EnvironmentalSelection([Population1,Offspring1,Offspring2,Offspring3],Problem.N,true,VAR);

                %种群2
                feasiIndex1=find(Population2.cons==0);
                Q2=[Population2,Offspring1,Offspring2 ,Offspring3];
                Fitness2=Single_Fitness(feasiIndex1,Q2,gen,VAR,N1,maxGen,1);
                [~,rank]   = sort( Fitness2);
                Population2 = Q2(rank(1:N1));
                Fitness2=Fitness2(rank(1:N1));
               
                %种群3
                feasiIndex2=find(Population3.cons==0);
                Q3 = [Population3,Offspring1,Offspring2 ,Offspring3];
                Fitness3=Single_Fitness(feasiIndex2,Q3,gen,VAR,N1,maxGen,2);
                [~,rank1]   = sort( Fitness3);                
                Population3 = Q3(rank1(1:N1));
                Fitness3=Fitness3(rank1(1:N1));

                
                X=X+1/maxGen;
                gen=gen+1;
            end
        end
    end
end


