    function J = test_function18(X,Dat)
    Xpop=size(X,1);
    Nvar=Dat.NVAR;
    M=Dat.NOBJ;
    J=ones(1,M);
       xpop=1;
         if (X(xpop,2)>-1&&X(xpop,2)<=0)&&((X(xpop,1)>7/6&&X(xpop,1)<=8/6)||(X(xpop,1)>9/6&&X(xpop,1)<=10/6)||(X(xpop,1)>11/6&&X(xpop,1)<=2))
   J(xpop,1)      = abs(X(xpop,1)-2);             
    J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2;
         end
         if (X(xpop,2)>-1&&X(xpop,2)<=0)&&((X(xpop,1)>2&&X(xpop,1)<=13/6)||(X(xpop,1)>14/6&&X(xpop,1)<=15/6)||(X(xpop,1)>16/6&&X(xpop,1)<=17/6))
   J(xpop,1)      = abs(X(xpop,1)-2);             
    J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2;
         end
         if (X(xpop,2)>1&&X(xpop,2)<=2)&&((X(xpop,1)>1&&X(xpop,1)<=7/6)||(X(xpop,1)>4/3&&X(xpop,1)<=3/2)||(X(xpop,1)>5/3&&X(xpop,1)<=11/6))
        X(xpop,2)=X(xpop,2)-1;
         J(xpop,1)      = abs(X(xpop,1)-2);             
    J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2; 
         end
             if (X(xpop,2)>1&&X(xpop,2)<=2)&&((X(xpop,1)>13/6&&X(xpop,1)<=14/6)||(X(xpop,1)>15/6&&X(xpop,1)<=16/6)||(X(xpop,1)>17/6&&X(xpop,1)<=3))
        X(xpop,2)=X(xpop,2)-1;
         J(xpop,1)      = abs(X(xpop,1)-2);             
    J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2; 
         end
          if (X(xpop,2)>0&&X(xpop,2)<=1)&&((X(xpop,1)>1&&X(xpop,1)<=7/6)||(X(xpop,1)>4/3&&X(xpop,1)<=3/2)||(X(xpop,1)>5/3&&X(xpop,1)<=11/6)||(X(xpop,1)>13/6&&X(xpop,1)<=14/6)||(X(xpop,1)>15/6&&X(xpop,1)<=16/6)||(X(xpop,1)>17/6&&X(xpop,1)<=3))
          J(xpop,1)      = abs(X(xpop,1)-2);             
    J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2; 
          end
          if (X(xpop,2)>0&&X(xpop,2)<=1)&&((X(xpop,1)>7/6&&X(xpop,1)<=8/6)||(X(xpop,1)>9/6&&X(xpop,1)<=10/6)||(X(xpop,1)>11/6&&X(xpop,1)<=2)||(X(xpop,1)>2&&X(xpop,1)<=13/6)||(X(xpop,1)>14/6&&X(xpop,1)<=15/6)||(X(xpop,1)>16/6&&X(xpop,1)<=17/6))
          X(xpop,2)=X(xpop,2)-1;
           J(xpop,1)      = abs(X(xpop,1)-2);             
    J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2; 
         end

    end
%     function J = test_function18(X,Dat)
%     Xpop=size(X,1);
%     Nvar=Dat.NVAR;
%     M=Dat.NOBJ;
%     J=ones(Xpop,M);
%     for xpop=1:Xpop
%          if (X(xpop,2)>-1&&X(xpop,2)<=0)&&((X(xpop,1)>7/6&&X(xpop,1)<=8/6)||(X(xpop,1)>9/6&&X(xpop,1)<=10/6)||(X(xpop,1)>11/6&&X(xpop,1)<=2))
%    J(xpop,1)      = abs(X(xpop,1)-2);             
%     J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2;
%          end
%          if (X(xpop,2)>-1&&X(xpop,2)<=0)&&((X(xpop,1)>2&&X(xpop,1)<=13/6)||(X(xpop,1)>14/6&&X(xpop,1)<=15/6)||(X(xpop,1)>16/6&&X(xpop,1)<=17/6))
%    J(xpop,1)      = abs(X(xpop,1)-2);             
%     J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2;
%          end
%          if (X(xpop,2)>1&&X(xpop,2)<=2)&&((X(xpop,1)>1&&X(xpop,1)<=7/6)||(X(xpop,1)>4/3&&X(xpop,1)<=3/2)||(X(xpop,1)>5/3&&X(xpop,1)<=11/6))
%         X(xpop,2)=X(xpop,2)-1;
%          J(xpop,1)      = abs(X(xpop,1)-2);             
%     J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2; 
%          end
%              if (X(xpop,2)>1&&X(xpop,2)<=2)&&((X(xpop,1)>13/6&&X(xpop,1)<=14/6)||(X(xpop,1)>15/6&&X(xpop,1)<=16/6)||(X(xpop,1)>17/6&&X(xpop,1)<=3))
%         X(xpop,2)=X(xpop,2)-1;
%          J(xpop,1)      = abs(X(xpop,1)-2);             
%     J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2; 
%          end
%           if (X(xpop,2)>0&&X(xpop,2)<=1)&&((X(xpop,1)>1&&X(xpop,1)<=7/6)||(X(xpop,1)>4/3&&X(xpop,1)<=3/2)||(X(xpop,1)>5/3&&X(xpop,1)<=11/6)||(X(xpop,1)>13/6&&X(xpop,1)<=14/6)||(X(xpop,1)>15/6&&X(xpop,1)<=16/6)||(X(xpop,1)>17/6&&X(xpop,1)<=3))
%           J(xpop,1)      = abs(X(xpop,1)-2);             
%     J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2; 
%           end
%           if (X(xpop,2)>0&&X(xpop,2)<=1)&&((X(xpop,1)>7/6&&X(xpop,1)<=8/6)||(X(xpop,1)>9/6&&X(xpop,1)<=10/6)||(X(xpop,1)>11/6&&X(xpop,1)<=2)||(X(xpop,1)>2&&X(xpop,1)<=13/6)||(X(xpop,1)>14/6&&X(xpop,1)<=15/6)||(X(xpop,1)>16/6&&X(xpop,1)<=17/6))
%           X(xpop,2)=X(xpop,2)-1;
%            J(xpop,1)      = abs(X(xpop,1)-2);             
%     J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2; 
%          end
%     end
%     end


