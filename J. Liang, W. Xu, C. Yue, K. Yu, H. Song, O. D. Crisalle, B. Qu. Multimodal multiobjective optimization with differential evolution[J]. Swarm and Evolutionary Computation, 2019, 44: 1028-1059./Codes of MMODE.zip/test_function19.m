
    function J = test_function19(X,Dat)
% x��ȡֵ��Χ1<=x1<=3    -1<=x2<=1

    Xpop=size(X,1);
    Nvar=Dat.NVAR;
    M=Dat.NOBJ;
    J=ones(1,M);
 xpop=1;
     X(xpop,1)= abs(X(xpop,1)-2);  
    J(xpop,1)      = X(xpop,1);             
    J(xpop,2)     = 1.0 - sqrt( X(xpop,1)) +( X(xpop,2)-(0.3*(X(xpop,1).^2)*cos(24*pi*X(xpop,1)+4*pi)+0.6*X(xpop,1))*sin(6*pi*X(xpop,1)+pi)).^2;
  
 
    end

%     function J = test_function19(X,Dat)
% % x��ȡֵ��Χ1<=x1<=3    -1<=x2<=1
% 
%     Xpop=size(X,1);
%     Nvar=Dat.NVAR;
%     M=Dat.NOBJ;
%     J=ones(Xpop,M);
%     for xpop=1:Xpop
%      X(xpop,1)= abs(X(xpop,1)-2);  
%     J(xpop,1)      = X(xpop,1);             
%     J(xpop,2)     = 1.0 - sqrt( X(xpop,1)) +( X(xpop,2)-(0.3*(X(xpop,1).^2)*cos(24*pi*X(xpop,1)+4*pi)+0.6*X(xpop,1))*sin(6*pi*X(xpop,1)+pi)).^2;
%     end
%  
% end