
    function J = test_function1(X,Dat)
% x��ȡֵ��Χ1<=x1<=3    -1<=x2<=1

    Xpop=size(X,1);
    Nvar=size(X,2);
    M=Dat.NOBJ;
    J=ones(1,M);
%     J=ones(Xpop,M);
    sum1=0;
    sum2=0;
%     for xpop=1:Xpop
      for nvar=1:Nvar-1
%           sum1=sum1+abs(X(xpop,nvar)-2);
%           sum2=sum2+sin(6*pi*abs(X(xpop,nvar)-2)+pi);
             sum1=sum1+abs(X(1,nvar)-2);
          sum2=sum2+sin(6*pi*abs(X(1,nvar)-2)+pi);       
      end
%     J(xpop,1)      = sum1;             
%     J(xpop,2)     = 1.0 - sqrt(sum1) + 2.0*( X(xpop,Nvar)-sum2).^2;
        J(1,1)      = sum1;             
    J(1,2)     = 1.0 - sqrt(sum1) + 2.0*(X(1,Nvar)-sum2).^2;
%     end
 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%test_function1����%%%%%%%%%%%%%%%
%     function J = test_function1(X,Dat)
% % x��ȡֵ��Χ1<=x1<=3    -1<=x2<=1
% 
%     Xpop=size(X,1);
%     Nvar=Dat.NVAR;
%     M=Dat.NOBJ;
%     J=ones(Xpop,M);
%     for xpop=1:Xpop
% %         for j=xpop+1:Xpop
%     J(xpop,1)      = abs(X(xpop,1)-2);             
%     J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2;
% %    J(xpop,1) =sum(sqrt((X(xpop,1)-X(j,1))^2+(X(xpop,2)-X(j,2))^2));
%     end
%  
% end
