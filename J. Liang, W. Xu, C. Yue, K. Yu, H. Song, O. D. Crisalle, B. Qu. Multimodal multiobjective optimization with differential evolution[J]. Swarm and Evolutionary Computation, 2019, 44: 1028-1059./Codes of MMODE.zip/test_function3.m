
 function J = test_function3(X,Dat)
% x��ȡֵ��Χ0<=x1<= 1  0<=x2<=1.5
    J=zeros(1,2);
     Xpop=size(X,1);

     J(1,1)      =  X(1,1);
    if X(1,2)>=0&&X(1,2)<=0.5                       %0<=x(2)<=0.5
        y2=X(1,2)-X(1,1)^0.5;
    end
    if X(1,2)>0.5&&X(1,2)<1&&X(1,1)>=0&&X(1,1)<=0.25    %0.5<x(2)<1&&0<=x(1)<=0.25
        y2=X(1,2)-0.5-X(1,1)^0.5;
    end
    if X(1,2)>0.5&&X(1,2)<1&&X(1,1)>0.25              %0.5<x(2)<1&&x(1)>0.25
        y2=X(1,2)-X(1,1)^0.5;
    end
    if X(1,2)>=1&&X(1,2)<=1.5                             %1<=x(2)<=1.5           
        y2=X(1,2)-0.5-X(1,1)^0.5;
    end
   J(1,2)      = 1.0 - (X(1,1))^0.5 + 2*((4*y2^2)-2*cos(20*y2*pi/sqrt(2))+2);

 end
%  function J = test_function3(X,Dat)
% % x��ȡֵ��Χ0<=x1<= 1  0<=x2<=1.5
%     J=zeros(2,1);
%      Xpop=size(X,1);
%      for xpop=1:Xpop 
%      J(xpop,1)      =  X(xpop,1);
%     if X(xpop,2)>=0&&X(xpop,2)<=0.5                       %0<=x(2)<=0.5
%         y2=X(xpop,2)-X(xpop,1)^0.5;
%     end
%     if X(xpop,2)>0.5&&X(xpop,2)<1&&X(xpop,1)>=0&&X(xpop,1)<=0.25    %0.5<x(2)<1&&0<=x(1)<=0.25
%         y2=X(xpop,2)-0.5-X(xpop,1)^0.5;
%     end
%     if X(xpop,2)>0.5&&X(xpop,2)<1&&X(xpop,1)>0.25              %0.5<x(2)<1&&x(1)>0.25
%         y2=X(xpop,2)-X(xpop,1)^0.5;
%     end
%     if X(xpop,2)>=1&&X(xpop,2)<=1.5                             %1<=x(2)<=1.5           
%         y2=X(xpop,2)-0.5-X(xpop,1)^0.5;
%     end
%    J(xpop,2)      = 1.0 - (X(xpop,1))^0.5 + 2*((4*y2^2)-2*cos(20*y2*pi/sqrt(2))+2);
%      end
% end