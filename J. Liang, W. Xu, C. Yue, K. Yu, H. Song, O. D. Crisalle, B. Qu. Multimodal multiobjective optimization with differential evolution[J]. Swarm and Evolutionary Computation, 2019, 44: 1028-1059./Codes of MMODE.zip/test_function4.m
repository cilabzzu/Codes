
 function J = test_function4(X,Dat)
% x��ȡֵ��Χ0<=xi<= 6  
       Xpop=size(X,1);
     J=zeros(1,2);
%  for xpop=1:Xpop
        J(1,1) =sin(pi*X(1,1))+sin(pi*X(1,2));
         J(1,2) = cos(pi*X(1,1))+cos(pi*X(1,2));
 end
%  function J = test_function4(X,Dat)
% % x��ȡֵ��Χ0<=xi<= 6  
%        Xpop=size(X,1);
%      J=zeros(Xpop,2);
%  for xpop=1:Xpop
%         J(xpop,1) =sin(pi*X(xpop,1))+sin(pi*X(xpop,2));
%          J(xpop,2) = cos(pi*X(xpop,1))+cos(pi*X(xpop,2));
% end