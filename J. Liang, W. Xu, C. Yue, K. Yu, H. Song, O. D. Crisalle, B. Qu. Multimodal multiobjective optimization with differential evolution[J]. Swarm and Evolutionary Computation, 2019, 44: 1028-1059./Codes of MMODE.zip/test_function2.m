function J = test_function2(X,Dat)
% x��ȡֵ��Χ0<=x1<= 1  0<=x2<=2
  J=zeros(1,2);
  Xpop=size(X,1);
  Nvar=size(X,2);
    if X(1,Nvar)>1
        X(1,2)=X(1,Nvar)-1;
    end
    J(1,1)        =  X(1,1);  
    y2=X(1,2)-X(1,1)^0.5;
     J(1,2)     = 1.0 - sqrt(X(1,1)) + 2*((4*y2^2)-2*cos(20*y2*pi/sqrt(2))+2);
 
 end
%  function J = test_function2(X,Dat)
% % x��ȡֵ��Χ0<=x1<= 1  0<=x2<=2
%   J=zeros(2,1);
%   Xpop=size(X,1);
%  for xpop=1:Xpop
%     if X(xpop,2)>1
%         X(xpop,2)=X(xpop,2)-1;
%     end
%     J(xpop,1)        =  X(xpop,1);  
%     y2=X(xpop,2)-X(xpop,1)^0.5;
%      J(xpop,2)     = 1.0 - sqrt(X(xpop,1)) + 2*((4*y2^2)-2*cos(20*y2*pi/sqrt(2))+2);
%  
%  end