    function J = test_function17(X,Dat)
    Xpop=size(X,1);
    Nvar=Dat.NVAR;
    M=Dat.NOBJ;
    J=ones(1,M);

         if X(1,2)>1
        X(1,2)=X(1,2)-2;
         end
    J(1,1)      = abs(X(1,1)-2);             
    J(1,2)     = 1.0 - sqrt( abs(X(1,1)-2)) + 2.0*( X(1,2)-sin(6*pi* abs(X(1,1)-2)+pi)).^2;

 
end
%     function J = test_function17(X,Dat)
%     Xpop=size(X,1);
%     Nvar=Dat.NVAR;
%     M=Dat.NOBJ;
%     J=ones(Xpop,M);
%     for xpop=1:Xpop
%          if X(xpop,2)>1
%         X(xpop,2)=X(xpop,2)-2;
%          end
%     J(xpop,1)      = abs(X(xpop,1)-2);             
%     J(xpop,2)     = 1.0 - sqrt( abs(X(xpop,1)-2)) + 2.0*( X(xpop,2)-sin(6*pi* abs(X(xpop,1)-2)+pi)).^2;
%     end
%  
% end
