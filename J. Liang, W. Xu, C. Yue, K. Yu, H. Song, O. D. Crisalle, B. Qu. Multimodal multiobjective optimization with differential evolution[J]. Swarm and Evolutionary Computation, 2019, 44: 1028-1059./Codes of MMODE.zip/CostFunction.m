function J=CostFunction(X,numfunction,Dat)   
  switch numfunction
       case 1

    J=test_function1(X,Dat);
       case 2

    J=test_function2(X,Dat);
       case 3

    J=test_function3(X,Dat);
       case 4

    J=test_function4(X,Dat);
 
      case 5
    J = test_function13(X,Dat); 
  
      case 6
    J = test_function14(X,Dat);
   
      case 7
    J = test_function15(X,Dat); 
  
      case 8
    J = test_function16(X,Dat);

      case 9
    J = test_function17(X,Dat); 

      case 10
    J = test_function18(X,Dat); 

      case 11
    J = test_function19(X,Dat);

      case 12
    J = test_function20(X,Dat); 

  end

 end
