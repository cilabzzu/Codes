
    function J = test_function15(X,Dat)
% x��ȡֵ��Χ-pi<=x1<=pi    0<=x2<=1

    Xpop=size(X,1);
    Nvar=Dat.NVAR;
    M=Dat.NOBJ;
    J=ones(1,M);
   
    J(1,1)      =X(1,1);             
    J(1,2)     =1.0 - X(1,1) + 2.0*( X(1,2)-sin(abs(X(1,1)))).^2;
  
    end

%     function J = test_function15(X,Dat)
% % x��ȡֵ��Χ-pi<=x1<=pi    0<=x2<=1
% 
%     Xpop=size(X,1);
%     Nvar=Dat.NVAR;
%     M=Dat.NOBJ;
%     J=ones(Xpop,M);
%     for xpop=1:Xpop
%     J(xpop,1)      =X(xpop,1);             
%     J(xpop,2)     =1.0 - X(xpop,1) + 2.0*( X(xpop,2)-sin(abs(X(xpop,1)))).^2;
%     end
% end