tic;
clear all;
 close all;
clc;
clear;
format long

MODEDat.times=1; 

% for t=1:MODEDat.times
%% Variables regarding the optimization problem
MODEDat.NOBJ =2;                          % Number of objectives
MODEDat.NRES = 0;                          % Number of constraints
MODEDat.NVAR   =2;                       % Numero of decision variables
MODEDat.mop = str2func('CostFunction');    % Cost function
MODEDat.numfunction=2;
%% Variables regarding the optimization algorithm
MODEDat.XPOP =100;                         % Population size
MODEDat.fixed_exdoc_number=800;
MODEDat.fixed_exdoc=zeros(MODEDat.fixed_exdoc_number,7);% 800
MODEDat.IGDx=[];
MODEDat.IGDf=[];
MODEDat.hyp=[];
MODEDat.meanIGDx=[];
MODEDat.meanIGDf=[];
MODEDat.meanhyp=[];
MODEDat.SDIGDx=[];
MODEDat.SDIGDf=[];
MODEDat.SDhyp=[];
%% Other variables  c
MODEDat.MAXFUNEVALS =800;  % Function evaluations 
MODEDat.MAXGEN = MODEDat.MAXFUNEVALS/(2*MODEDat.XPOP);                       
MODEDat.SaveResults='no';                 
MODEDat.CounterGEN=0;
MODEDat.CounterFES=0;
OUT=MODE(MODEDat);   % Run the algorithm.
toc;
