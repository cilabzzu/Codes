
    function J = test_function20(X,Dat)
% x��ȡֵ��Χ-pi<=x1<=pi    0<=x2<=9

    Xpop=size(X,1);
    Nvar=Dat.NVAR;
    M=Dat.NOBJ;
    J=ones(1,M);
xpop=1;
         if X(xpop,2)>4
        X(xpop,2)=X(xpop,2)-4;
         end
    J(xpop,1)      = sin(abs(X(xpop,1)));             
    J(xpop,2)     = sqrt(1.0 - (sin(abs(X(xpop,1)))).^2) + 2.0*( X(xpop,2)-(sin(abs(X(xpop,1)))+abs(X(xpop,1)))).^2;

 
    end
%  function J = test_function20(X,Dat)
% % x��ȡֵ��Χ-pi<=x1<=pi    0<=x2<=9
% 
%     Xpop=size(X,1);
%     Nvar=Dat.NVAR;
%     M=Dat.NOBJ;
%     J=ones(Xpop,M);
%     for xpop=1:Xpop
%          if X(xpop,2)>4
%         X(xpop,2)=X(xpop,2)-4;
%          end
%     J(xpop,1)      = sin(abs(X(xpop,1)));             
%     J(xpop,2)     = sqrt(1.0 - (sin(abs(X(xpop,1)))).^2) + 2.0*( X(xpop,2)-(sin(abs(X(xpop,1)))+abs(X(xpop,1)))).^2;
%     end
%  
% end