function OUT=MODE(MODEDat)
Xpop          = MODEDat.XPOP;      % Population size.
NP_Size=Xpop;  % Population size.
Nvar          = MODEDat.NVAR;      % Number of decision variables.
Nobj          = MODEDat.NOBJ;      % Number of objectives.
mop           = MODEDat.mop;       % Cost function.
max_numfunction=MODEDat.numfunction;
times         = MODEDat.times; 
IGDx=MODEDat.IGDx;
IGDf=MODEDat.IGDf;
hyp=MODEDat.hyp;
meanIGDx=MODEDat.meanIGDx;
meanIGDf=MODEDat.meanIGDf;
meanhyp=MODEDat.meanhyp;
SDIGDx=MODEDat.SDIGDx;
SDIGDf=MODEDat.SDIGDf;
SDhyp=MODEDat.SDhyp;
for numfunction=1:max_numfunction;
    for t=1:times

maxFES=MODEDat.MAXFUNEVALS;
%% Initial random population
Parent = [];  % Parent population. 
Mutant = [];  % Mutant population.
Child  = [];  % Child population.
exdoc=[];     % ex document to save nondominated solutions
fixed_exdoc_number=MODEDat.fixed_exdoc_number;
fixed_exdoc=MODEDat.fixed_exdoc;% 800
FES    = MODEDat.CounterFES;% Function Evaluation.
count_temp=0;
switch numfunction
    case 1
%         for nvar=1:Nvar-1
  Parent(:,1) =ones(Xpop,1)+2*rand(Xpop,1);%%%%%%%%%%%%test_function1%%%%%%%%%%%%%
%   Parent(:,2:Nvar-1) =Parent(:,1) ;%%%%%%%%%%%%test_function1%%%%%%%%%%%%%  
   for nvar=2:Nvar-1
  Parent(:,nvar) =Parent(:,1);%%%%%%%%%%%%test_function1%%%%%%%%%%%%%   
   end  
  Parent(:,Nvar) =(Nvar-1)*(-ones(Xpop,1)+2*rand(Xpop,1)); %%%%%%%%%%%%test_function1%%%%%%%%%%%%% 
    case 2
  Parent(:,1) =rand(Xpop,1);%%%%%%%%%%%%test_function2%%%%%%%%%%%%%
  Parent(:,2) =2*rand(Xpop,1); %%%%%%%%%%%%test_function2%%%%%%%%%%%%%   
    case 3
  Parent(:,1) =rand(Xpop,1);%%%%%%%%%%%%test_function3%%%%%%%%%%%%%
  Parent(:,2) =1.5*rand(Xpop,1); %%%%%%%%%%%%test_function3%%%%%%%%%%%%%  
    case 4
     Parent=6*rand(Xpop,Nvar);%%%%%%%%%%%%test_function4%%%%%%%%%%%%%
   case 5
  Parent(:,1) =-pi+2*pi*rand(Xpop,1);%%%%%%%%%%%%%%%%%%%%%%%%%
  Parent(:,2) =rand(Xpop,1); %%%%%%%%%%%%%%%%%%%%%%%% 
     case 6
  Parent(:,1) =-pi+2*pi*rand(Xpop,1);%%%%%%%%%%%%%%%%%%%%%%%%%
  Parent(:,2) =2*rand(Xpop,1); %%%%%%%%%%%%%%%%%%%%%%%%% 
     case 7
  Parent(:,1) =-pi+2*pi*rand(Xpop,1);%%%%%%%%%%%%%%%%%%%%%%%%%
  Parent(:,2) =rand(Xpop,1); %%%%%%%%%%%%%%%%%%%%%%%% 
     case 8
  Parent(:,1) =-pi+2*pi*rand(Xpop,1);%%%%%%%%%%%%%%%%%%%%%%%%%
  Parent(:,2) =rand(Xpop,1); %%%%%%%%%%%%%%%%%%%%%%%% 
   case 9
  Parent(:,1) =ones(Xpop,1)+2*rand(Xpop,1);%%%%%%%%%%%%test_function17%%%%%%%%%%%%%
  Parent(:,2) =-ones(Xpop,1)+4*rand(Xpop,1); %%%%%%%%%%%%test_function17%%%%%%%%%%%%% 
   case 10
  Parent(:,1) =ones(Xpop,1)+2*rand(Xpop,1);%%%%%%%%%%%%test_function18%%%%%%%%%%%%%
  Parent(:,2) =-ones(Xpop,1)+3*rand(Xpop,1); %%%%%%%%%%%%test_function18%%%%%%%%%%%%% 
   case 11
  Parent(:,1) =ones(Xpop,1)+2*rand(Xpop,1);%%%%%%%%%%%%test_function19%%%%%%%%%%%%%
  Parent(:,2) =-ones(Xpop,1)+2*rand(Xpop,1); %%%%%%%%%%%%test_function19%%%%%%%%%%%%% 
   case 12
  Parent(:,1) =-pi+2*pi*rand(Xpop,1);%%%%%%%%%%%%%%%%%%%%%%%%%
  Parent(:,2) =9*rand(Xpop,1); %%%%%%%%%%%%%%%%%%%%%%%%% 
end

for parent=1:Xpop
JxParent(parent,1:2) = mop(Parent(parent,:),numfunction,MODEDat);
FES = FES+1;  
end

%% Evolution process
while FES<maxFES   
%    lamat=maxFES/(maxFES+FES);
%    CrossOverP=0.5*(exp(lamat)-1); 
%    ScalingFactor=0.5*(exp(lamat)-0.6);
 CrossOverP=0.9; 
 ScalingFactor=0.5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% nondominated solution sorting 
% mutation individuals are selected according to tournament 
Parentstar=[Parent,JxParent];
Parentstar(:,1:Nobj+Nvar+3) = non_domination_sort_mod(Parentstar,Nobj,Nvar);
Parent_tophalf = replace_decision_chromosome(Parentstar,Nobj,Nvar, Xpop/2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for xpop=1:Xpop

        rev=randperm(Xpop/2);

        %% Mutant vector calculation

  Mutant(xpop,:)=Parent_tophalf(rev(1,1),:)+ScalingFactor*(Parent_tophalf(rev(1,2),:)-Parent_tophalf(rev(1,3),:)+Parent_tophalf(rev(1,4),:)-Parent_tophalf(rev(1,5),:));  
randnumber=randperm(Xpop);
switch numfunction
    case 1
%%%%%%%%%%%%%%%%%%%%%%%%%%test_function1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %% boundary restriction
    
     if Mutant(xpop,1)<=1
                Mutant(xpop,1) =Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>3
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%           Mutant(xpop,nvar)=1;      
     end

     if Mutant(xpop,1)>=3
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<1
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,nvar)=3;
     end
       for nvar=2:Nvar-1
           Mutant(xpop,nvar)=Mutant(xpop,1);
            if Mutant(xpop,nvar)<=1
                Mutant(xpop,nvar) =Parent_tophalf(rev(1,1),nvar)-ScalingFactor*(Parent_tophalf(rev(1,2),nvar)-Parent_tophalf(rev(1,3),nvar)+Parent_tophalf(rev(1,4),nvar)-Parent_tophalf(rev(1,5),nvar));
                if Mutant(xpop,nvar)>3
                   Mutant(xpop,nvar)=Parent(randnumber(1,1),nvar);
                end
%           Mutant(xpop,nvar)=1;      
     end

     if Mutant(xpop,nvar)>=3
         Mutant(xpop,nvar)=Parent_tophalf(rev(1,1),nvar)-ScalingFactor*(Parent_tophalf(rev(1,2),nvar)-Parent_tophalf(rev(1,3),nvar)+Parent_tophalf(rev(1,4),nvar)-Parent_tophalf(rev(1,5),nvar));
         if Mutant(xpop,nvar)<1
             Mutant(xpop,nvar)=Parent(randnumber(1,1),nvar);
         end
%          Mutant(xpop,nvar)=3;
     end
           
      end
        if Mutant(xpop,Nvar)<=-1*(Nvar-1)
                Mutant(xpop,Nvar) =Parent_tophalf(rev(1,1),Nvar)-ScalingFactor*(Parent_tophalf(rev(1,2),Nvar)-Parent_tophalf(rev(1,3),Nvar)+Parent_tophalf(rev(1,4),Nvar)-Parent_tophalf(rev(1,5),Nvar));
                if Mutant(xpop,Nvar)>1*(Nvar-1)
                   Mutant(xpop,Nvar)=Parent(randnumber(1,1),Nvar);
                end
%                 Mutant(xpop,Nvar)=-1*(Nvar-1);
         end

   if Mutant(xpop,Nvar)>=1*(Nvar-1)
        Mutant(xpop,Nvar)=Parent_tophalf(rev(1,1),Nvar)-ScalingFactor*(Parent_tophalf(rev(1,2),Nvar)-Parent_tophalf(rev(1,3),Nvar)+Parent_tophalf(rev(1,4),Nvar)-Parent_tophalf(rev(1,5),Nvar));
          if Mutant(xpop,Nvar)<-1*(Nvar-1)
              Mutant(xpop,Nvar)=Parent(randnumber(1,1),Nvar);
          end
%           Mutant(xpop,Nvar)=1*(Nvar-1);
   end

        case 2
            %%%%%%%%%%%%%%%%%%%%%%%%%%%test_function2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
             if Mutant(xpop,1)<=0
                Mutant(xpop,1) =Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>1
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=0;
     end

     if Mutant(xpop,1)>=1
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<0
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=1;
     end

        if Mutant(xpop,2)<=0
                Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
                if Mutant(xpop,2)>2
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
                end
%              Mutant(xpop,2)=0;   
         end

   if Mutant(xpop,2)>=2
        Mutant(xpop,2)=Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
          if Mutant(xpop,2)<0
              Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=2;
   end

        case 3
         %%%%%%%%%%%%%%%%%%%%%%%%%%%test_function3%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
            if Mutant(xpop,1)<=0
                Mutant(xpop,1) =Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>1
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=0;
           end

     if Mutant(xpop,1)>=1
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<0
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=1;
     end

        if Mutant(xpop,2)<=0
                Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
                if Mutant(xpop,2)>1.5
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
                end
%                 Mutant(xpop,2)=0;
         end

   if Mutant(xpop,2)>=1.5
          Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
          if Mutant(xpop,2)<0
              Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=1.5;
   end
        case 4
            %%%%%%%%%%%%%%%%%%%%%%%%%%%test_function4%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
            if Mutant(xpop,1)<=0
               Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>6
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=0;
           end

     if Mutant(xpop,1)>=6
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<0
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=6;
     end

        if Mutant(xpop,2)<=0
               Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
                if Mutant(xpop,2)>6
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
                end
%                 Mutant(xpop,2)=0;
         end

   if Mutant(xpop,2)>=6
        Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
          if Mutant(xpop,2)<0
              Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=6;
   end
    case 5
  %%%%%%%%%%%%%%%%%%%%%%%%%%%Omni-Test%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
               if Mutant(xpop,1)<=-pi
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
%             Mutant(xpop,1)=Parent(rev(1,1),1)-ScalingFactor*(Parent(rev(1,2),1)-Parent(rev(1,3),1)+Parent(rev(1,4),1)-Parent(rev(1,5),1));
                if Mutant(xpop,1)>pi
%                    Mutant(xpop,1)=Parent_tophalf(rev(1,1),1);
                    Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=-pi;
           end

     if Mutant(xpop,1)>=pi
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
%       Mutant(xpop,1)=Parent(rev(1,1),1)-ScalingFactor*(Parent(rev(1,2),1)-Parent(rev(1,3),1)+Parent(rev(1,4),1)-Parent(rev(1,5),1));

         if Mutant(xpop,1)<-pi
%              Mutant(xpop,1)=Parent_tophalf(rev(1,1),1);
               Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=pi;
     end

        if Mutant(xpop,2)<=0
                 Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
%               Mutant(xpop,2) =Parent(rev(1,1),2)-ScalingFactor*(Parent(rev(1,2),2)-Parent(rev(1,3),2)+Parent(rev(1,4),2)-Parent(rev(1,5),2));
 
                 if Mutant(xpop,2)>1
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
%                       Mutant(xpop,2)=Parent_tophalf(rev(1,1),2);
                end
%                 Mutant(xpop,2)=0;
         end

   if Mutant(xpop,2)>=1
           Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
%           Mutant(xpop,2) =Parent(rev(1,1),2)-ScalingFactor*(Parent(rev(1,2),2)-Parent(rev(1,3),2)+Parent(rev(1,4),2)-Parent(rev(1,5),2));

           if Mutant(xpop,2)<0
%               Mutant(xpop,2)=Parent_tophalf(rev(1,1),2);
               Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=1;
   end
       case 6
  %%%%%%%%%%%%%%%%%%%%%%%%%%%Omni-Test%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
               if Mutant(xpop,1)<=-pi
                Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>pi
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=-pi;
           end

     if Mutant(xpop,1)>=pi
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<-pi
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=pi;
     end

        if Mutant(xpop,2)<=0
                 Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
                if Mutant(xpop,2)>2
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
                end
%                 Mutant(xpop,2)=0;
         end

   if Mutant(xpop,2)>=2
           Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
          if Mutant(xpop,2)<0
              Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=2;
   end
       case 7
  %%%%%%%%%%%%%%%%%%%%%%%%%%%Omni-Test%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
               if Mutant(xpop,1)<=-pi
                Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>pi
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=-pi;
           end

     if Mutant(xpop,1)>=pi
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<-pi
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=pi;
     end

        if Mutant(xpop,2)<=0
                 Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
                if Mutant(xpop,2)>1
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
                end
%                 Mutant(xpop,2)=0;
         end

   if Mutant(xpop,2)>=1
           Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
          if Mutant(xpop,2)<0
              Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=1;
   end
    case 8
  %%%%%%%%%%%%%%%%%%%%%%%%%%%Omni-Test%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
               if Mutant(xpop,1)<=-pi
                Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>pi
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=-pi;
           end

     if Mutant(xpop,1)>=pi
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<-pi
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=pi;
     end

        if Mutant(xpop,2)<=0
                 Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
                if Mutant(xpop,2)>1
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
                end
%                 Mutant(xpop,2)=0;
         end

   if Mutant(xpop,2)>=1
           Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
          if Mutant(xpop,2)<0
              Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=1;
   end
    case 9
%%%%%%%%%%%%%%%%%%%%%%%%%%test_function17%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %% boundary restriction
     if Mutant(xpop,1)<=1
                Mutant(xpop,1) =Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>3
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=1;
     end

     if Mutant(xpop,1)>=3
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<1
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=3;
     end

        if Mutant(xpop,2)<=-1
                Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
                if Mutant(xpop,2)>3
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
                end
%                 Mutant(xpop,2)=-1;
         end

   if Mutant(xpop,2)>=3
        Mutant(xpop,2)=Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
          if Mutant(xpop,2)<-1
              Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=3;
   end
   case 10
%%%%%%%%%%%%%%%%%%%%%%%%%%test_function17%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %% boundary restriction
     if Mutant(xpop,1)<=1
                Mutant(xpop,1) =Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>3
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=1;
     end

     if Mutant(xpop,1)>=3
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<1
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=3;
     end

        if Mutant(xpop,2)<=-1
                Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
                if Mutant(xpop,2)>2
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
                end
%                 Mutant(xpop,2)=-1;
         end

   if Mutant(xpop,2)>=2
        Mutant(xpop,2)=Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
          if Mutant(xpop,2)<-1
              Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=2;
   end
    case 11
%%%%%%%%%%%%%%%%%%%%%%%%%%test_function1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %% boundary restriction
     if Mutant(xpop,1)<=1
                Mutant(xpop,1) =Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>3
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=1;
     end

     if Mutant(xpop,1)>=3
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<1
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=3;
     end

        if Mutant(xpop,2)<=-1
                Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
                if Mutant(xpop,2)>1
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
                end
%                 Mutant(xpop,2)=-1;
         end

   if Mutant(xpop,2)>=1
        Mutant(xpop,2)=Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
          if Mutant(xpop,2)<-1
              Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=1;
   end
    case 12
  %%%%%%%%%%%%%%%%%%%%%%%%%%%Omni-Test%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
               if Mutant(xpop,1)<=-pi
                Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
                if Mutant(xpop,1)>pi
                   Mutant(xpop,1)=Parent(randnumber(1,1),1);
                end
%                 Mutant(xpop,1)=-pi;
           end

     if Mutant(xpop,1)>=pi
         Mutant(xpop,1)=Parent_tophalf(rev(1,1),1)-ScalingFactor*(Parent_tophalf(rev(1,2),1)-Parent_tophalf(rev(1,3),1)+Parent_tophalf(rev(1,4),1)-Parent_tophalf(rev(1,5),1));
         if Mutant(xpop,1)<-pi
             Mutant(xpop,1)=Parent(randnumber(1,1),1);
         end
%          Mutant(xpop,1)=pi;
     end

        if Mutant(xpop,2)<=0
                 Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
                if Mutant(xpop,2)>9
                   Mutant(xpop,2)=Parent(randnumber(1,1),2);
                end
%                 Mutant(xpop,2)=0;
         end

   if Mutant(xpop,2)>=9
           Mutant(xpop,2) =Parent_tophalf(rev(1,1),2)-ScalingFactor*(Parent_tophalf(rev(1,2),2)-Parent_tophalf(rev(1,3),2)+Parent_tophalf(rev(1,4),2)-Parent_tophalf(rev(1,5),2));
          if Mutant(xpop,2)<0
              Mutant(xpop,2)=Parent(randnumber(1,1),2);
          end
%           Mutant(xpop,2)=9;
   end
end  
        %% Crossover operator
        for nvar=1:Nvar
            if rand() > CrossOverP
%                 Child(xpop,nvar) =Parent(xpop,nvar);
%                 rev2=randperm(Xpop);
                 Child(xpop,nvar) =Parent(xpop,nvar); 
            else
                Child(xpop,nvar) = Mutant(xpop,nvar);
            end
        end

    end
    for child=1:Xpop
    JxChild(child,1:2) = mop(Child(child,:),numfunction,MODEDat);
   FES=FES+1;
    end
   %% nondominated sort
sumPC=[Parent;Child];
JxsumPC=[JxParent;JxChild];
subParent1star=[sumPC,JxsumPC];
subParent1star(:,1:Nobj+Nvar+3) = non_domination_sort_mod(subParent1star,Nobj,Nvar);
[row_subParent1star column_subParent1star]=size(subParent1star);
% subParent1star_decision_sort=sortrows(subParent1star,Nobj+Nvar+3);
% subParent1star_objective_sort=sortrows(subParent1star,Nobj+Nvar+2);
% subParent1star_decision_sort_half=subParent1star_decision_sort(1:Xpop,:);
% subParent1star_objective_sort_half=subParent1star_objective_sort(1:Xpop,:);
firstfront_all=length(find(subParent1star(:,5)==1));
% secondfront_all=length(find(subParent1star(:,5)==2));
% thirdfront_all=length(find(subParent1star(:,5)==3));
% fouthfront_all=length(find(subParent1star(:,5)==4));
% fifthfront_all=length(find(subParent1star(:,5)==5));
% figure(5)
% % plot(FES,firstfront_all,'k*')
% % hold on
% % plot(FES,secondfront_all,'kd')
% % hold on
% % plot(FES,firstfront_all+secondfront_all+thirdfront_all+fouthfront_all+fifthfront_all,'b*')
% % hold on
% % plot(FES,Xpop,'r*-')
% % hold on 
% %  grid on
% %  title('fronts are changed with FES');
% %   xlabel('FES');
% %   ylabel('front number of several fronts');
% saveas(gcf,'FES.jpg')

      row_exdoc =size(exdoc,1);
      column_exdoc=size(exdoc,2);
    if row_exdoc==0
    exdoc(1:firstfront_all,:)=subParent1star(1:firstfront_all,:);
    else
       for i=1:Xpop    
         for j=1:row_exdoc
          if subParent1star(i,Nvar+1:Nvar+Nobj)<=exdoc(j,Nvar+1:Nvar+Nobj)
              exdoc(j,:)=subParent1star(i,:);
          else
              count_temp=count_temp+1;
          end
         end
          if count_temp==row_exdoc
          exdoc=[exdoc;subParent1star(i,:)];
                 row_exdoc=row_exdoc+1;
% %%%�������֧��������ȫ������������֮��ֻѡ��Ψһֵ�� 
%           else
%             exdoc=unique(exdoc);
%              row_exdoc=size(exdoc,1);
% %%%�������֧��������ȫ������������֮��ֻѡ��Ψһֵ�� 
          end
          count_temp=0;%%��������
      end
    end
    exdoc=unique(exdoc,'rows');
  
     row_exdoc=size(exdoc,1);
%      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%decision space
%     exdoc=sortrows(exdoc,column_exdoc); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%objective space
  exdoc=sortrows(exdoc,column_exdoc-1); 
    if row_exdoc<Xpop  
      particle(1:Xpop-row_exdoc,:) = replace_chromosome(subParent1star,Nobj,Nvar, Xpop-row_exdoc);    
      particle(1+Xpop-row_exdoc:Xpop,:) =exdoc; 
    else
    particle=exdoc(row_exdoc-Xpop+1:row_exdoc,:);
  
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    row_fixed_exdoc=size(fixed_exdoc,1);
    if  row_fixed_exdoc<fixed_exdoc_number
        fixed_exdoc(row_fixed_exdoc+1:row_fixed_exdoc+Xpop,:)=[fixed_exdoc;particle];
    else
          fixed_exdoc=non_domination_sort_mod(fixed_exdoc,Nobj,Nvar);
          fixed_exdoc=replace_chromosome(fixed_exdoc,Nobj,Nvar,fixed_exdoc_number);    
    end

%% select solutions until the sum is Xpop
    Parent=particle(:,1:Nvar);
   JxParent=particle(:,Nvar+1:Nvar+Nobj); 

end

%     figure(6)
%  plot(Parent(:,1),Parent(:,2),'r*')
% 
%  title('PS')
%  xlabel('x1');
%   ylabel('x2');
%   saveas(gcf,['F:\ѧϰ\�о���\DE�㷨�����Ŀ���������\MMODE\MONSDE-2017-02-14\figure\����ͼ��','PS',num2str(numfunction),'popsize',num2str(Xpop),'.fig']);
% %   zlabel('x3');
% figure(7)
%  plot(JxParent(:,1),JxParent(:,2),'r*')
%  title('PF')
%  xlabel('f1');
%   ylabel('f2');
%   saveas(gcf,['F:\ѧϰ\�о���\DE�㷨�����Ŀ���������\MMODE\MONSDE-2017-02-14\figure\����ͼ��','PF',num2str(numfunction),'popsize',num2str(Xpop),'.fig']);
 PFront=JxParent;
 PSet=Parent; 
    OUT.PSet           = PSet;     % Pareto Set
    OUT.PFront         = PFront;   % Pareto Front
    OUT.Param          = MODEDat;  % MODE Parameters 
   
%     MODEDat.CounterGEN = n
%     MODEDat.CounterFES = FES;
%     function_number=numfunction
    %%%%%%%%%%%%%%%%%%%%���Pareto�⼯��Paretoǰ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%     if FES>MODEDat.MAXFUNEVALS
% %             if FES>MODEDat.MAXFUNEVALS || n>MODEDat.MAXGEN
%         disp('Termination criteria reached.')
%         break;
%     end
% % figure(8)
% %    plot(PSet(:,1),PSet(:,2),'r*')
% % 
% %   grid on
% %   title('PSet')
% %    xlabel('x1');
% %   ylabel('x2');
% %   figure(9)
% %   plot(PFront(:,1),PFront(:,2),'rd')
% %  grid on
% %   title('PFront')
% %  xlabel('f1');
% %   ylabel('f2');
%   PSet=sortrows(PSet,1);
%   PFront=sortrows(PFront,1);
  ps=PSet;
  pf=PFront;
  %% produce true PF and PS
 %%%%%%%%%%%%%%%%%%%%%%%%%%for ploting  %%%%%%%%%%%%%%%%%%%%%%%%%
 Xpop=Xpop;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Xpop=row_fixed_exdoc;
switch numfunction
    case 1
            repoint=[Nvar,Nvar];
            PS  = zeros(Nvar,Xpop);
            PS(1,:)     = linspace(1,3,Xpop);
            sum3=0;
            for nvar=2:Nvar-1
            PS(nvar,:)     =PS(1,:); 
            end
            for nvar=1:Nvar-1
            sum3 =sum3+ sin(6.0*pi*abs(PS(nvar,:)-2)+pi);
            end
            PS(Nvar,:)=sum3;
            PS=PS';
            PF  = zeros(Nobj,Xpop);

            PF(1,:)     = linspace(0,Nvar-1,Xpop);
            PF(2,:)     = 1-sqrt(PF(1,:));
            PF=PF';   

    case 2
            repoint=[2,2];
            PS  = zeros(2,Xpop);
            PS(2,1:1/2*Xpop)     = linspace(0,1,1/2*Xpop);
            PS(1,1:1/2*Xpop)     =PS(2,1:1/2*Xpop).^2;
            PS(2,1/2*Xpop+1:Xpop)     = linspace(1,2,1/2*Xpop);
            PS(1,1/2*Xpop+1:Xpop)     =(PS(2,1/2*Xpop+1:Xpop)-1).^2;
            PS=PS';
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(0,1,Xpop);
            PF(2,:)     = 1-sqrt(PF(1,:));
            PF=PF';   

    case 3
            repoint=[2,2];
            PS  = zeros(2,Xpop);
            PS(2,1:1/2*Xpop)     = linspace(0,1,1/2*Xpop);
            PS(1,1:1/2*Xpop)     =PS(2,1:1/2*Xpop).^2;
            PS(2,1/2*Xpop+1:Xpop)     = linspace(0.5,1.5,1/2*Xpop);
            PS(1,1/2*Xpop+1:Xpop)     =(PS(2,1/2*Xpop+1:Xpop)-0.5).^2;
            PS=PS';
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(0,1,Xpop);
            PF(2,:)     = 1-sqrt(PF(1,:));
            PF=PF';   

    case 4
            repoint=[1,1];
            fraction=round(1/9*Xpop);
            PS  = zeros(2,Xpop);
            PS(1,1:fraction)=linspace(1,1.5,fraction);
            PS(2,1:fraction)=linspace(1,1.5,fraction);
            PS(1,fraction+1:2*fraction)=linspace(1,1.5,fraction); 
             PS(2,fraction+1:2*fraction)=linspace(3,3.5,fraction);
            PS(1,2*fraction+1:3*fraction)=linspace(1,1.5,fraction);
             PS(2,2*fraction+1:3*fraction)=linspace(5,5.5,fraction);        
            PS(1,3*fraction+1:4*fraction)=linspace(3,3.5,fraction);
            PS(2,3*fraction+1:4*fraction)=linspace(1,1.5,fraction); 
            PS(1,4*fraction+1:5*fraction)=linspace(3,3.5,fraction);
             PS(2,4*fraction+1:5*fraction)=linspace(3,3.5,fraction);
            PS(1,5*fraction+1:6*fraction)=linspace(3,3.5,fraction);
             PS(2,5*fraction+1:6*fraction)=linspace(5,5.5,fraction);
            PS(1,6*fraction+1:7*fraction)=linspace(5,5.5,fraction);
            PS(2,6*fraction+1:7*fraction)=linspace(1,1.5,fraction);
            PS(1,7*fraction+1:8*fraction)=linspace(5,5.5,fraction);
            PS(2,7*fraction+1:8*fraction)=linspace(3,3.5,fraction);
            PS(1,8*fraction+1:9*fraction)=linspace(5,5.5,fraction);
            PS(2,8*fraction+1:9*fraction)=linspace(5,5.5,fraction);
            PS=PS';
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(-2,0,Xpop);
            PF(2,:)     = -sqrt(2^2-(PF(1,:)).^2);
            PF=PF'; 

    case 5
            repoint=[2,2];
            PS  = zeros(2,Xpop);
            PS(1,:)     = linspace(-pi,pi,Xpop);
            PS(2,:) = sin(abs(PS(1,:)));
            PS=PS';
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(0,1,Xpop);
            PF(2,:)     = sqrt(1-(PF(1,:).^2));
            PF=PF';  

   case 6
            repoint=[2,2];
            PS  = zeros(2,Xpop);
            PS(1,1:1/2*Xpop)     = linspace(-pi,pi,1/2*Xpop);
            PS(1,1/2*Xpop+1:Xpop)     = linspace(-pi,pi,1/2*Xpop); 
            PS(2,1:1/2*Xpop) = sin(abs(PS(1,1:1/2*Xpop)));     
            PS(2,1/2*Xpop+1:Xpop)=sin(abs(PS(1,1/2*Xpop+1:Xpop)))+1; 
            PS=PS';    
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(0,1,Xpop);
            PF(2,:)     = sqrt(1-(PF(1,:).^2));
            PF=PF';

    case 7
            repoint=[2,2];
            PS  = zeros(2,Xpop);
            PS(1,:)     = linspace(-pi,pi,Xpop);
            PS(2,:) = sin(abs(PS(1,:)));
            PS=PS';
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(-pi,pi,Xpop);
            PF(2,:)     = 1-PF(1,:);
            PF=PF'; 

    case 8
            repoint=[5,40];
            PS  = zeros(2,Xpop);
            PS(1,:)     = linspace(-pi,pi,Xpop);
            PS(2,:) = sin(abs(PS(1,:)));
            PS=PS';
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(-pi,pi,Xpop);
            PF(2,:)     = 1-(PF(1,:)).^3;
            PF=PF';    

     case 9
            repoint=[2,2];
            PS  = zeros(2,Xpop);
            PS(1,1:1/2*Xpop)     = linspace(1,3,1/2*Xpop);
            PS(2,1:1/2*Xpop) = sin(6.0*pi*abs(PS(1,1:1/2*Xpop)-2)+pi);
            PS(1,1/2*Xpop+1:Xpop)     = linspace(1,3,1/2*Xpop);
            PS(2,1/2*Xpop+1:Xpop) = sin(6.0*pi*abs(PS(1,1/2*Xpop+1:Xpop)-2)+pi)+2;
            PS=PS';
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(0,1,Xpop);
            PF(2,:)     = 1-sqrt(PF(1,:));
            PF=PF';   

    case 10
            repoint=[2,2];
            PS  = zeros(2,Xpop);
            PS(1,1:1/2*Xpop)     = linspace(1,3,1/2*Xpop);
            PS(2,1:1/2*Xpop) = sin(6.0*pi*abs(PS(1,1:1/2*Xpop)-2)+pi);
            PS(1,1/2*Xpop+1:Xpop)     = linspace(1,3,1/2*Xpop);
            PS(2,1/2*Xpop+1:Xpop) = sin(6.0*pi*abs(PS(1,1/2*Xpop+1:Xpop)-2)+pi)+1;
            PS=PS';
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(0,1,Xpop);
            PF(2,:)     = 1-sqrt(PF(1,:));
            PF=PF';   

            case 11
            repoint=[2,2];
            PS  = zeros(2,Xpop);
            PS(1,:)     = linspace(1,3,Xpop);
            PS(2,:) = (0.3*(abs(PS(1,:)-2).^2).*cos(24*pi*abs(PS(1,:)-2)+4*pi)+0.6*abs(PS(1,:)-2)).*sin(6*pi*abs(PS(1,:)-2)+pi);
            PS=PS';
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(0,1,Xpop);
            PF(2,:)     = 1-sqrt(PF(1,:));
            PF=PF';  

            case 12
            repoint=[2,2];
            PS  = zeros(2,Xpop);
            PS(1,1:1/2*Xpop)     = linspace(-pi,pi,1/2*Xpop);
            PS(1,1/2*Xpop+1:Xpop)     = linspace(-pi,pi,1/2*Xpop); 
            PS(2,1:1/2*Xpop) = sin(abs(PS(1,1:1/2*Xpop)))+abs(PS(1,1:1/2*Xpop));     
            PS(2,1/2*Xpop+1:Xpop)=sin(abs(PS(1,1/2*Xpop+1:Xpop)))+abs(PS(1,1:1/2*Xpop))+4; 
            PS=PS';    
            PF  = zeros(2,Xpop);
            PF(1,:)     = linspace(0,1,Xpop);
            PF(2,:)     = sqrt(1-(PF(1,:).^2));
            PF=PF';
            
end
%   figure
%  
%  plot(ps(:,1),ps(:,2),'b*')
% % legend('MMODSDE');
%   hold on
% 
%  plot(PS(:,1),PS(:,2),'r.')
%   title('PS')
%  xlabel('x1');
%   ylabel('x2');
%  legend('MMODE','true PS');
% saveas(gcf,['F:\ѧϰ\�о���\DE�㷨�����Ŀ���������\MMODE\MONSDE-2017-02-14\figure\����ͼ��','PS',num2str(numfunction),'popsize',num2str(NP_Size),'fixed_exdoc_size',num2str(Xpop),'.fig']);
% hold off
% figure
%  
%  plot(pf(:,1),pf(:,2),'b*')
% % legend('MMODSDE');
%   hold on  
% plot(PF(:,1),PF(:,2),'r.')
% title('PF')
%  xlabel('f1');
%   ylabel('f2');
% legend('MMODE','true PF');
% saveas(gcf,['F:\ѧϰ\�о���\DE�㷨�����Ŀ���������\MMODE\MONSDE-2017-02-14\figure\����ͼ��','PF',num2str(numfunction),'popsize',num2str(NP_Size),'fixed_exdoc_size',num2str(Xpop),'.fig']);
% hold off

    Xpop=NP_Size;%%%%%%%%%%%%%%%%%%%%%%%%%keep Xpop fixed%%%%%%%%%%%%%%
%    disp(['MMODE with initial mutation ' 'testfunction=  ' num2str(numfunction) ])
%    disp(['MMODE with initial mutation ' 'runtimes=  ' num2str(t) ])
%       disp(['MMODE with initial selection ' 'testfunction=  ' num2str(numfunction) ])
%    disp(['MMODE with initial selection ' 'runtimes=  ' num2str(t) ])
         disp(['MMODE ' 'testfunction=  ' num2str(numfunction) ])
   disp(['MMODE ' 'runtimes=  ' num2str(t) ])
%      disp(['MMODE ' 'testfunction=  ' num2str(numfunction) ])
%    disp(['MMODE ' 'runtimes=  ' num2str(t) ]) 
row_IGDx=size(IGDx,1);
row_IGDf=size(IGDf,1);
row_hyp=size(hyp,1);
  IGDx(row_IGDx+1,1)=IGD_calculation(ps,PS);
% figure(1);
% plot(FES,IGDx(row_IGDx+1,1),'b*')
% hold on
  IGDf(row_IGDf+1,1)=IGD_calculation(pf,PF);
% figure(2);
% plot(FES,IGDf(row_IGDf+1,1),'b*')
% hold on
  hyp(row_hyp+1,1)=Hybervolume_calculation(pf,repoint);
% figure(3);
% plot(FES,hyp(row_hyp+1,1),'b*')
% hold on
% end
%  FES=0;  
 
    end

   function_number=numfunction;
   runtime_all=times;
   row_meanIGDx=size(meanIGDx,1);
   row_meanIGDf=size(meanIGDf,1);
   row_meanhyp=size(meanhyp,1);
%  meanIGDx(row_meanIGDx+1,1)=mean(IGDx(times*(numfunction-1)+1:times*(numfunction-0),1))  
%  meanIGDf(row_meanIGDf+1,1)=mean(IGDf(times*(numfunction-1)+1:times*(numfunction-0),1))
%  meanhyp(row_meanhyp+1,1)=mean(hyp(times*(numfunction-1)+1:times*(numfunction-0),1))
%   meanIGDx(row_meanIGDx+1,1)=mean(IGDx(times*(numfunction-13)+1:times*(numfunction-12),1))
%  meanIGDf(row_meanIGDf+1,1)=mean(IGDf(times*(numfunction-13)+1:times*(numfunction-12),1))
%  meanhyp(row_meanhyp+1,1)=mean(hyp(times*(numfunction-13)+1:times*(numfunction-12),1))
%     row_SDIGDx=size(SDIGDx,1);
%    row_SDIGDf=size(SDIGDf,1);
%    row_SDhyp=size(SDhyp,1);
%  SDIGDx(row_SDIGDx+1,1)=std(IGDx(times*(numfunction-1)+1:times*(numfunction-0),1));
% SDIGDf(row_SDIGDf+1,1)=std(IGDf(times*(numfunction-1)+1:times*(numfunction-0),1));
% SDhyp(row_SDhyp+1,1)=std(hyp(times*(numfunction-1)+1:times*(numfunction-0),1));
%  SDIGDx(row_SDIGDx+1,1)=std(IGDx(times*(numfunction-13)+1:times*(numfunction-12),1));
% SDIGDf(row_SDIGDf+1,1)=std(IGDf(times*(numfunction-13)+1:times*(numfunction-12),1));
% SDhyp(row_SDhyp+1,1)=std(hyp(times*(numfunction-13)+1:times*(numfunction-12),1));
 OUT.IGDx=IGDx;
 OUT.IGDf=IGDf;
 OUT.hyp=hyp;
 OUT.meanIGDx=meanIGDx;
 OUT.meanIGDf=meanIGDf;
 OUT.meanhyp=meanhyp;
  OUT.SDIGDx=SDIGDx;
 OUT.SDIGDf=SDIGDf;
 OUT.SDShyp=SDhyp;
end


