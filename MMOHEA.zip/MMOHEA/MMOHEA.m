
function [ps,pf]=MMOHEA(func_name,VRmin,VRmax,n_obj,Particle_Number,Max_Gen)


% Dimension: n_var --- dimensions of decision space 
%            n_obj --- dimensions of objective space
%% Input:
%                      Dimension                    Description
%      func_name       1 x length function name     the name of test function     
%      VRmin           1 x n_var                    low bound of decision variable
%      VRmax           1 x n_var                    up bound of decision variable
%      n_obj           1 x 1                        dimensions of objective space
%      Particle_Number 1 x 1                        population size
%      Max_Gen         1 x 1                        maximum  generations

%% Output:
%                     Description
%      ps             Pareto set
%      pf             Pareto front
%%  Reference and Contact 


%% Initialize parameters
    n_var=size(VRmin,2);               %Obtain the dimensions of decision space
    Max_FES=Max_Gen*Particle_Number;   %Maximum fitness evaluations
    pre_num=floor(Particle_Number/2);        
    num_archive=400;
    ex_archive=[];

%% Initialize particles' positions and velocities
    mv=0.5*(VRmax-VRmin);
    VRmin=repmat(VRmin,Particle_Number,1);
    VRmax=repmat(VRmax,Particle_Number,1);
    Vmin=repmat(-mv,Particle_Number,1);
    Vmax=-Vmin;
    pos=VRmin+(VRmax-VRmin).*rand(Particle_Number,n_var); %initialize the positions of the particles
    vel=Vmin+2.*Vmax.*rand(Particle_Number,n_var);        %initialize the velocities of the particles

    %% Evaluate the population
    fitness=zeros(Particle_Number,n_obj);
    for i=1:Particle_Number;
        fitness(i,:)=feval(func_name,pos(i,:));
    end
    fitcount=Particle_Number;            % count the number of fitness evaluations
    particle=[pos,fitness];              %put positions and velocities in one matrix

   particle=ENS_SCD(particle(:,1:n_var+n_obj), n_obj, n_var);

   pre_select_particle=particle(1:pre_num,1:n_var); 
   pbest=pos;  
   cr=0.9; 
   F=0.5;

  for i=1:Max_Gen  
      
%       disp(['��' num2str(i) '�� '])      
       
    particle_I=particle;
    P_Dec  = particle(:,1:n_var);   
    [N,D]  = size(P_Dec); 
    P_Obj  = particle(:,n_var+1:n_var+n_obj);
    V      = vel;
    Off_P  = zeros(N,D);
    Off_V  = zeros(N,D);  
    LeaderSet =[1; 2; 3; 4; 5; 6; 7; 8 ;9; 10];     
    for k = 1 : N
        winner = LeaderSet(randperm(length(LeaderSet),2));
        c1     = dot(P_Obj(k,:),P_Obj(winner(1),:))/(norm(P_Obj(k,:))*norm(P_Obj(winner(1),:)));
        angle1 = rad2deg(acos(c1));
        c2     = dot(P_Obj(k,:),P_Obj(winner(2),:))/(norm(P_Obj(k,:))*norm(P_Obj(winner(2),:)));
        angle2 = rad2deg(acos(c2));
        mask   = (angle1 > angle2);
        winner = ~mask.*winner(1) + mask.*winner(2);
        r1 = rand(1,D);
        r2 = rand(1,D);
        r3 = rand(1,D);
        Off_V(k,:) = r1.*V(k,:)+r3.*(P_Dec(winner,:)-pbest(k,1:n_var));
        vel=Off_V;
        % Make sure that velocities are in the setting bounds.
             vel(k,:)=(vel(k,:)>mv).*mv+(vel(k,:)<=mv).*vel(k,:); 
             vel(k,:)=(vel(k,:)<(-mv)).*(-mv)+(vel(k,:)>=(-mv)).*vel(k,:);
        Off_P(k,:) = P_Dec(k,:) + Off_V(k,:);
        pos=Off_P;
        % Make sure that positions are in the setting bounds.
             pos(k,:)=((pos(k,:)>=VRmin(1,:))&(pos(k,:)<=VRmax(1,:))).*pos(k,:)...
                 +(pos(k,:)<VRmin(1,:)).*(VRmin(1,:)+0.25.*(VRmax(1,:)-VRmin(1,:)).*rand(1,n_var))+(pos(k,:)>VRmax(1,:)).*(VRmax(1,:)-0.25.*(VRmax(1,:)-VRmin(1,:)).*rand(1,n_var));
             % Evaluate the population
            fitness(k,:)=feval(func_name,pos(k,1:n_var));
            fitcount=fitcount+1;
            particle(k,1:n_var+n_obj)=[pos(k,:),fitness(k,:)];           
    end

    particle_II=ENS_SCD(particle(:,1:n_var+n_obj), n_obj, n_var);   
    
    for k = 1 : N       
       temp=(particle_I(k,n_var+n_obj+2)>particle_II(k,n_var+n_obj+2));
       pbest(k,1:n_var+n_obj)=temp.*particle_I(k,1:n_var+n_obj)+(1-temp).*particle_II(k,1:n_var+n_obj);      
    end 
    particle_III=ENS_SCD(pbest(:,1:n_var+n_obj), n_obj, n_var);        
    for k=1:N
        [temp kk]=sort(sqrt(sum((ones(N,1)*pbest(k,1:n_var)-pbest(:,1:n_var)).^2,2)));
        pb_1=particle_III(:,n_var+n_obj+2);
        if pb_1(kk(1))>=pb_1(kk(2))
            nbest1=pbest(kk(1),1:n_var);
            nbest2=pbest(kk(2),1:n_var);
        else
            nbest2=pbest(kk(1),1:n_var);
            nbest1=pbest(kk(2),1:n_var); 
        end
       temp_pbest(k,:)=pbest(k,1:n_var)+2*rand*(nbest1-nbest2);                
       temp_pbest(k,:)=((temp_pbest(k,:)>=VRmin(1,:))&(temp_pbest(k,:)<=VRmax(1,:))).*temp_pbest(k,:)...
            +(temp_pbest(k,:)<VRmin(1,:)).*(VRmin(1,:)+0.25.*(VRmax(1,:)-VRmin(1,:)).*rand(1,n_var))+(temp_pbest(k,:)>VRmax(1,:)).*(VRmax(1,:)-0.25.*(VRmax(1,:)-VRmin(1,:)).*rand(1,n_var));
       temp_fitness(k,:)=feval(func_name,temp_pbest(k,:));
        temp_fitness(k,:)=temp_fitness(k,:)';           
        fitcount=fitcount+1;        
        particle_IV(k,1:n_var+n_obj)=[temp_pbest(k,:),temp_fitness(k,:)];       
    end  
    particle_IV=ENS_SCD(particle_IV(:,1:n_var+n_obj), n_obj, n_var);      
    for k = 1 : N       
        temp=(particle_III(k,n_var+n_obj+2)>particle_IV(k,n_var+n_obj+2));
       pbest(k,1:n_var+n_obj)=temp.*particle_III(k,1:n_var+n_obj)+(1-temp).*particle_IV(k,1:n_var+n_obj);       
    end   

     for xpop = 1 : Particle_Number   
     rev=randperm(pre_num);
     Mutant(xpop,:)=pre_select_particle(rev(1,1),:)+F*(pre_select_particle(rev(1,2),:)-pre_select_particle(rev(1,3),:)+pre_select_particle(rev(1,4),:)-pre_select_particle(rev(1,5),:));      
     randnumber=randperm(Particle_Number);   
     
     low_index=Mutant(xpop,:)<=VRmin(xpop,:);
     Mutant(xpop,low_index)=pre_select_particle(rev(1,1),low_index)-F*(pre_select_particle(rev(1,2),...
     low_index)-pre_select_particle(rev(1,3),low_index)+pre_select_particle(rev(1,4),low_index)-pre_select_particle(rev(1,5),low_index));
     low_up_i=Mutant(xpop,:)>VRmax(xpop,:);
     Mutant(xpop,low_up_i)=particle(randnumber(1,1),low_up_i);

     up_index=Mutant(xpop,:)>=VRmax(xpop,:);     
     Mutant(xpop,up_index) =pre_select_particle(rev(1,1),up_index)-F*(pre_select_particle(rev(1,2),...
     up_index)-pre_select_particle(rev(1,3),up_index)+pre_select_particle(rev(1,4),up_index)-pre_select_particle(rev(1,5),up_index));
     up_low_i=Mutant(xpop,:)<VRmin(xpop,:);
     Mutant(xpop,up_low_i)=particle(randnumber(1,1),up_low_i);

     if rand()>cr
         Child(xpop,:) =particle(xpop,1:n_var); 
            else
         Child(xpop,:) =Mutant(xpop,1:n_var);
     end     
            fitness_pre(xpop,:)=feval(func_name,Child(xpop,1:n_var));
            fitcount=fitcount+1;
           particle_pre(xpop,1:n_var+n_obj)=[Child(xpop,:),fitness_pre(xpop,:)];          
     end
     
         ex_archive=[ex_archive;particle_pre(:,1:n_var+n_obj);particle(:,1:n_var+n_obj)];
         temp_archive=ex_archive;
         temp_archive=unique(temp_archive,'rows','stable');
         temp_archive=ENS_SCD(temp_archive(:,1:n_var+n_obj), n_obj, n_var);
         
             if size(temp_archive,1)>num_archive
                 archive=temp_archive(1:num_archive,:);
             else
                archive=temp_archive;
             end   
             
             ex_archive=archive(:,1:n_var+n_obj);
             particle=temp_archive(1:Particle_Number,:);
             pre_select_particle=temp_archive(1:pre_num,1:n_var); 

    if fitcount>Max_FES;                
        break;
    end
  end

   tempindex=find(archive(:,n_var+n_obj+1)==1);% Find the index of the first rank particles
   ps=archive(tempindex,1:n_var);
   pf=archive(tempindex,n_var+1:n_var+n_obj);
  
  end
 
  function f = ENS_SCD(x,n_obj,n_var)
 
    PopObj = x(:,n_var+1:n_var+n_obj);
    PopDec = x(:,1:n_var);
    [N,M]  = size(PopObj);
    nSort=N;
    
    % Use efficient non-dominated sort with sequential search (ENS-SS)
    [FrontNo,MaxFNo] = ENS_SS(PopObj,nSort);
      
       CrowdDis_obj= CDistance_obj(PopObj,FrontNo);
       CrowdDis_dec= CDistance_dec(PopDec,FrontNo);
       avg_CrowdDis_obj=mean(CrowdDis_obj./n_obj);
       avg_CrowdDis_dec=mean(CrowdDis_dec./n_var);
             
       for i=1:N
           if (CrowdDis_obj(i)>avg_CrowdDis_obj)|(CrowdDis_dec(i)>avg_CrowdDis_dec)
               CrowdDis_interaction(i)=max(CrowdDis_obj(i),CrowdDis_dec(i));                  
           else
              CrowdDis_interaction(i)=min(CrowdDis_obj(i),CrowdDis_dec(i));         
           end    
       end
       
    x(:,n_var+n_obj+1)=FrontNo';
    x(:,n_var+n_obj+2)=CrowdDis_interaction';
    x(:,n_var+n_obj+3)=CrowdDis_dec';
    x(:,n_var+n_obj+4)=CrowdDis_obj';
      
    x=sortrows(x,[n_var+n_obj+1,-(n_var+n_obj+2)]);
    f=x;

end
      
  function [FrontNo,MaxFNo] = ENS_SS(PopObj,nSort)
    [PopObj,~,Loc] = unique(PopObj,'rows');
    Table          = hist(Loc,1:max(Loc));
    [N,M]          = size(PopObj);
    [PopObj,rank]  = sortrows(PopObj);
    FrontNo        = inf(1,N);
    MaxFNo         = 0;
    while sum(Table(FrontNo<inf)) < min(nSort,length(Loc))
        MaxFNo = MaxFNo + 1;
        for i = 1 : N
            if FrontNo(i) == inf
                Dominated = false;
                for j = i-1 : -1 : 1
                    if FrontNo(j) == MaxFNo
                        m = 2;
                        while m <= M && PopObj(i,m) >= PopObj(j,m)
                            m = m + 1;
                        end
                        Dominated = m > M;
                        if Dominated || M == 2
                            break;
                        end
                    end
                end
                if ~Dominated
                    FrontNo(i) = MaxFNo;
                end
            end
        end
    end
    FrontNo(rank) = FrontNo;
    FrontNo = FrontNo(:,Loc);
    end
               
  function CrowdDis = CDistance_obj(PopObj,FrontNo)
% Calculate the crowding distance of each solution front by front

%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    [N,M]    = size(PopObj);
    CrowdDis = zeros(1,N);
    Fronts   = setdiff(unique(FrontNo),inf);
    for f = 1 : length(Fronts)
        Front = find(FrontNo==Fronts(f));
        Fmax  = max(PopObj(Front,:),[],1);
        Fmin  = min(PopObj(Front,:),[],1);
        for i = 1 : M
            [~,Rank] = sortrows(PopObj(Front,i));
            if length(Rank)==1
                CrowdDis(Front(Rank(1)))   = 1;
            else
            CrowdDis(Front(Rank(1)))   = 0.5;
            CrowdDis(Front(Rank(end))) = 0.5;
            end
            for j = 2 : length(Front)-1
                if (Fmax(i)-Fmin(i))==0
                    CrowdDis(Front(Rank(j))) =1;
                else
                CrowdDis(Front(Rank(j))) = CrowdDis(Front(Rank(j)))+(PopObj(Front(Rank(j+1)),i)-PopObj(Front(Rank(j-1)),i))/(Fmax(i)-Fmin(i));
                end
            end
        end
    end
    
   
       end
      
  function CrowdDis = CDistance_dec(PopDec,FrontNo)
% Calculate the crowding distance of each solution front by front

%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    [N,M]    = size(PopDec);
    CrowdDis = zeros(1,N);
    Fronts   = setdiff(unique(FrontNo),inf);
    for f = 1 : length(Fronts)
        Front = find(FrontNo==Fronts(f));
        Fmax  = max(PopDec(Front,:),[],1);
        Fmin  = min(PopDec(Front,:),[],1);
        for i = 1 : M
            [~,Rank] = sortrows(PopDec(Front,i));
            if length(Rank)==1
                CrowdDis(Front(Rank(1)))   = 1;
            else
                CrowdDis(Front(Rank(1)))   = 2*(PopDec(Front(Rank(2)),i)-PopDec(Front(Rank(1)),i))/(Fmax(i)-Fmin(i));
                CrowdDis(Front(Rank(end))) = 2*(PopDec(Front(Rank(end)),i)-PopDec(Front(Rank(end-1)),i))/(Fmax(i)-Fmin(i));
%             CrowdDis(Front(Rank(1)))   = inf;
%             CrowdDis(Front(Rank(end))) = inf;
            end
            for j = 2 : length(Front)-1
                if (Fmax(i)-Fmin(i))==0
                    CrowdDis(Front(Rank(j))) =1;
                else
                CrowdDis(Front(Rank(j))) = CrowdDis(Front(Rank(j)))+(PopDec(Front(Rank(j+1)),i)-PopDec(Front(Rank(j-1)),i))/(Fmax(i)-Fmin(i));
                end
            end
        end 
    end
   
    
       end
 


