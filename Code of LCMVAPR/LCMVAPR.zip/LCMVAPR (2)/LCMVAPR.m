    classdef LCMVAPR < ALGORITHM
    % <multi/many> <real> <large><constrained>
    % Evolutionary algorithm for large-scale many-objective optimization
    % nSel ---  5 --- Number of selected solutions for decision variable clustering
    % nPer --- 50 --- Number of perturbations on each solution for decision variable clustering
    % nCor ---  5 --- Number of selected solutions for decision variable interaction analysis
    % type ---  1 --- Type of operator (1. GA 2. DE)
    % alpha ---   2 --- The parameter controlling the rate of change of penalty
    % fr    --- 0.1 --- The frequency of employing reference vector adaptation

    %------------------------------- Reference --------------------------------
    % X. Zhang, Y. Tian, R. Cheng, and Y. Jin, A decision variable clustering
    % based evolutionary algorithm for large-scale many-objective optimization,
    % IEEE Transactions on Evolutionary Computation, 2018, 22(1): 97-112.
    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "PlatEMO" and reference "Ye
    % Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
    % for evolutionary multi-objective optimization [educational forum], IEEE
    % Computational Intelligence Magazine, 2017, 12(4): 73-87".
    %--------------------------------------------------------------------------

        methods
            function main(Algorithm,Problem)
                %% Parameter setting  LMEA
                [nSel,nPer,nCor,type] = Algorithm.ParameterSet(5,50,5,1);

                %% Generate random population
                Population     = Problem.Initialization();
                [V,Problem.N] = UniformPoint(100,Problem.M);
                arch1=Population;
           %% 切换条件初始化
                change_threshold   = 0.05;
                last_gen           = 35;
                a=1;
                b=1;
                mean1=[];
                mean2=[];
                FrontNo = NDSort(Population.objs,inf);
                Population_first=Population(FrontNo==1);
                mean1 = Normalization(Population_first,mean1,a);
                mean2 = Normalization(Population,mean2,b);



                %% Detect the group of each distance variable
                 [PV,DV]= VariableClustering(Problem,Population,nSel,nPer);
                DVSet   = CorrelationAnalysis(Problem,Population,DV,nCor);
                flag=0;
                [N2,~] = size(Population.decs);
                %% Optimization
            while Algorithm.NotTerminated(Population)
                  %The First Steep
                  if flag==0
                    [Population,Offspring]= ConvergenceOptimization(Population,DVSet,type);
%                           存档
                    arch1= Update_arch1([Offspring,arch1],N2*2); 
                    a=a+1;
                    FrontNo = NDSort(Population.objs,inf);
                    Population_first=Population(FrontNo==1);
                    mean1 = Normalization(Population_first,mean1,a);
                     if a>last_gen && (max(abs(mean1(a,:)-mean1(a-last_gen,:))))<=change_threshold
                         flag=1;
                     end
                  end

                  if flag==1  
                      [Population,Offspring] = DistributionOptimization(Population,PV);
                      arch1= Update_arch1([Offspring,arch1],N2*2); 
                      b=b+1;
                      mean2 = Normalization(Population,mean2,b);
                      if b>last_gen && (max(abs(mean2(b,:)-mean2(b-last_gen,:))))<=change_threshold
                          flag=2;
                      end
                      FE=Problem.FE;
                  end
                  
                  if  flag==2       
                      Population1=arch1;
                      [N1,~] = size(Population1.decs);
                      Obj=Population1.objs;
                      Obj = Obj - repmat(min(Obj,[],1),N1,1);
                      Z0 = min(Obj,[],1);
                    for i=1:length(Obj)
                        d1(i,:)=norm(Obj(i,:)-Z0);
                    end    
                    [d1,retain]=rmoutliers(d1,'mean');
                    Obj=Obj(~retain,:);                    
                    Population1=Population1(retain==0);                    
                    Angle = acos(1-pdist2(Obj,V,'cosine'));
                    [~,associate] = min(Angle,[],2);
                    Population=[]; 
                   for i = unique(associate)'
                   d=d1(associate==i);
                   Population_current=Population1(associate==i);
                   mid= median(d);
                   best=Population_current(d>=mid);
                   Population=[Population,best];
                   end
                    figure();
                    obj=Population.objs;
                    scatter(obj(:,1),obj(:,2));
                   cons = Population.cons;
                   cons(cons<0) = 0;
                   VAR0 = mean(sum(cons,2));
                   if VAR0 == 0
                       VAR0 = 1;
                   end                  
                   X=0;
                   Fitness = CalFitness(Population.objs,Population.cons);
                   flag=3;
                  end   
                   if flag==3
                       cp=(-log(VAR0)-6)/log(1-0.5);
                       VAR = VAR0*(1-X)^cp;
                       MatingPool = TournamentSelection(2,2*N2,Fitness);
                       Offspring  = OperatorGAhalf(Population(MatingPool));
                       [Population,Fitness]   = Auxiliray_task_EnvironmentalSelection([Population,Offspring],N2,VAR);
                       X=(Problem.FE-FE)/(Problem.maxFE-FE);
                   end
            end

          end
        end
    end

   function [Population,Offspring] = ConvergenceOptimization(Population,DVSet,type)
    [N,D] = size(Population.decs);
    Con   = calCon(Population.objs);
    for i = 1 : length(DVSet)
        for j = 1 : length(DVSet{i})
            % Select parents
            MatingPool = TournamentSelection(2,2*N,Con);
            % Generate offsprings
            OffDec = Population.decs;
            if type == 1
                NewDec = OperatorGAhalf(Population(MatingPool).decs,{5,20,D/length(DVSet{i})/2,20});
            elseif type == 2
                NewDec = OperatorDE(Population.decs,Population(MatingPool(1:end/2)).decs,Population(MatingPool(end/2+1:end)).decs,{1,0.5,D/length(DVSet{i})/2,20});
            end
            OffDec(:,DVSet{i}) = NewDec(:,DVSet{i});
            Offspring          = SOLUTION(OffDec);
            % Update each solution
            allCon  = calCon([Population.objs;Offspring.objs]);
            Con     = allCon(1:N);
            newCon  = allCon(N+1:end);
            updated = Con > newCon;
            Population(updated) = Offspring(updated);
            Con(updated)        = newCon(updated);
        end
    end
   end
 
 function [Population,Offspring] = DistributionOptimization(Population,PV)
% Distribution optimization

    N            = length(Population);
    OffDec       = Population(TournamentSelection(2,N,calCon(Population.objs))).decs;
    NewDec       = OperatorGA(Population(randi(N,1,N)).decs);
    OffDec(:,PV) = NewDec(:,PV);
    Offspring    = SOLUTION(OffDec);
    Population   = EnvironmentalSelection([Population,Offspring],N);
 end

 function Con = calCon(PopuObj)
 % Calculate the convergence of each solution
 
 FrontNo = NDSort(PopuObj,inf);
 Con     = sum(PopuObj,2);
 Con     = FrontNo'*(max(Con)-min(Con)) + Con;
 end
 
 function CV = CV_arch(Population)
 % Calculate the convergence of each solution
 
 CV = sum(max(0,Population.cons),2);
 end